<?php

return [
    'welcome' => 'ยินดีต้อนรับ',
    'login'   => 'เข้าสู่ระบบ',
    'email'   => 'ที่อยู่อีเมล',
    'password' => 'รหัสผ่าน',
];