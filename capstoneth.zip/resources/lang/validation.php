<?php

return [
    'required' => 'จำเป็นต้องกรอก :attribute',
    'email' => 'รูปแบบอีเมลไม่ถูกต้อง',
    'min' => [
        'string' => ':attribute ต้องมีอย่างน้อย :min ตัวอักษร',
    ],
];
