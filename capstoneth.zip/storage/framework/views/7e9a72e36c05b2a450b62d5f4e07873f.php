<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'LATER-X')); ?></title>

    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" crossorigin="anonymous"/>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>

<body class="font-sans antialiased bg-gray-100">

<div x-data="{ sidebarOpen: false }" class="flex">

    
    <aside class="hidden md:flex flex-col justify-between w-64 h-screen bg-green-50 text-gray-800 shadow fixed">
        <div>
            <div class="p-6">
                <img src="<?php echo e(asset('images/laterx-logo.png')); ?>" class="mx-auto w-28 mb-2" alt="LATER-X Logo">
                <h2 class="text-2xl font-bold text-center text-green-700"><?php echo e(config('app.name', 'LATER-X')); ?></h2>
            </div>

            <nav class="mt-6 space-y-1">
                <a href="<?php echo e(route('dashboard.index')); ?>"
                   class="block px-6 py-2 rounded <?php echo e(request()->routeIs('dashboard*') ? 'bg-green-200 font-semibold text-green-900' : 'hover:bg-green-100'); ?>">
                    <?php echo e(__('Dashboard')); ?>

                </a>

                <a href="<?php echo e(route('transactions.index')); ?>"
                   class="block px-6 py-2 rounded <?php echo e(request()->routeIs('transactions.index') ? 'bg-green-200 font-semibold text-green-900' : 'hover:bg-green-100'); ?>">
                    <?php echo e(__('Latex Monitoring')); ?>

                </a>

                <a href="<?php echo e(route('transactions.create')); ?>"
                   class="block px-6 py-2 rounded <?php echo e(request()->routeIs('transactions.create') ? 'bg-green-200 font-semibold text-green-900' : 'hover:bg-green-100'); ?>">
                    <?php echo e(__('Create Transaction')); ?>

                </a>

                <a href="<?php echo e(route('plots.index')); ?>"
                   class="block px-6 py-2 rounded <?php echo e(request()->routeIs('admin.plots.*') || request()->routeIs('staff.plots.*') ? 'bg-green-200 font-semibold text-green-900' : 'hover:bg-green-100'); ?>">
                    <?php echo e(__('Plot Management')); ?>

                </a>

                <a href="<?php echo e(route('farmer.index')); ?>"
                   class="block px-6 py-2 rounded <?php echo e(request()->routeIs('admin.farmer.*') || request()->routeIs('staff.farmer.index') ? 'bg-green-200 font-semibold text-green-900' : 'hover:bg-green-100'); ?>">
                    <?php echo e(__('Farmers')); ?>

                </a>

                <?php if(auth()->user()->hasRole('admin')): ?>
                    <a href="<?php echo e(route('admin.users')); ?>"
                       class="block px-6 py-2 rounded <?php echo e(request()->routeIs('admin.users*') ? 'bg-green-200 font-semibold text-green-900' : 'hover:bg-green-100'); ?>">
                        <?php echo e(__('User Management')); ?>

                    </a>
                <?php endif; ?>
            </nav>
        </div>

        
        <div x-data="{ open: false }" class="mb-6 px-6 relative">
            <button @click="open = !open"
                    class="flex items-center space-x-2 w-full px-4 py-2 bg-green-200 rounded hover:bg-green-300 transition-colors duration-300">
                <i class="fas fa-user-circle text-2xl text-green-700"></i>
                <span class="font-semibold text-green-700 hidden md:block"><?php echo e(auth()->user()->name); ?></span>
                <i class="fas fa-chevron-down ml-auto text-green-700"></i>
            </button>

            <div x-show="open" @click.away="open = false"
                 class="absolute bottom-full left-0 mb-2 w-full bg-white border rounded shadow-lg z-50 p-2">
                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="w-full text-left px-4 py-2 text-red-500 hover:bg-red-100 rounded">
                        <?php echo e(__('Logout')); ?>

                    </button>
                </form>
            </div>
        </div>
    </aside>

    
    <aside x-show="sidebarOpen" @click.away="sidebarOpen = false"
           class="fixed inset-y-0 left-0 w-64 bg-green-50 text-gray-800 shadow z-50 flex flex-col justify-between md:hidden">
        <div>
            <div class="p-6 flex justify-between items-center">
                <img src="<?php echo e(asset('images/laterx-logo.png')); ?>" class="w-28" alt="LATER-X Logo">
                <button @click="sidebarOpen = false" class="text-gray-600 hover:text-gray-800">
                    <i class="fas fa-times text-xl"></i>
                </button>
            </div>

            <nav class="mt-6 space-y-1">
                <a href="<?php echo e(route('dashboard.index')); ?>" class="block px-6 py-2 rounded hover:bg-green-100"><?php echo e(__('Dashboard')); ?></a>
                <a href="<?php echo e(route('transactions.index')); ?>" class="block px-6 py-2 rounded hover:bg-green-100"><?php echo e(__('Latex Monitoring')); ?></a>
                <a href="<?php echo e(route('transactions.create')); ?>" class="block px-6 py-2 rounded hover:bg-green-100"><?php echo e(__('Create Transaction')); ?></a>
                <a href="<?php echo e(route('plots.index')); ?>" class="block px-6 py-2 rounded hover:bg-green-100"><?php echo e(__('Plot Management')); ?></a>
                <a href="<?php echo e(route('farmer.index')); ?>" class="block px-6 py-2 rounded hover:bg-green-100"><?php echo e(__('Farmers')); ?></a>
                <?php if(auth()->user()->hasRole('admin')): ?>
                    <a href="<?php echo e(route('admin.users')); ?>" class="block px-6 py-2 rounded hover:bg-green-100"><?php echo e(__('User Management')); ?></a>
                <?php endif; ?>
            </nav>
        </div>

        <div class="mb-6 px-6">
            <form method="POST" action="<?php echo e(route('logout')); ?>">
                <?php echo csrf_field(); ?>
                <button type="submit" class="w-full flex items-center space-x-2 px-4 py-2 bg-red-50 text-red-600 rounded hover:bg-red-100">
                    <i class="fas fa-sign-out-alt"></i>
                    <span><?php echo e(__('Logout')); ?></span>
                </button>
            </form>
        </div>
    </aside>

    
    <div class="flex-1 md:ml-64 min-h-screen flex flex-col">
        
        
        <header class="bg-white shadow-sm h-16 flex items-center justify-between px-8 z-10 sticky top-0">
            <div class="flex items-center">
                <button @click="sidebarOpen = true" class="text-green-700 md:hidden focus:outline-none mr-4">
                    <i class="fas fa-bars text-2xl"></i>
                </button>
                <h2 class="hidden md:block text-sm font-medium text-gray-500">
                    <?php echo e(__('LATER-X Decision Support System')); ?>

                </h2>
            </div>

            <div class="flex items-center space-x-4">
                
                <div class="flex bg-gray-100 rounded-lg p-1">
                    <a href="<?php echo e(route('lang.switch', 'en')); ?>" 
                       class="px-3 py-1 text-xs font-bold rounded-md transition-all <?php echo e(app()->getLocale() == 'en' ? 'bg-white shadow text-green-600' : 'text-gray-500 hover:text-green-600'); ?>">
                        EN
                    </a>
                    <a href="<?php echo e(route('lang.switch', 'th')); ?>" 
                       class="px-3 py-1 text-xs font-bold rounded-md transition-all <?php echo e(app()->getLocale() == 'th' ? 'bg-white shadow text-green-600' : 'text-gray-500 hover:text-green-600'); ?>">
                        TH
                    </a>
                </div>
                
                <div class="h-6 w-px bg-gray-200"></div>

            </div>
        </header>

        
        <?php if(isset($header)): ?>
            <header class="text-white bg-green-600 shadow">
                <div class="px-4 py-6 mx-auto max-w-7xl sm:px-6 lg:px-8">
                    <?php echo e($header); ?>

                </div>
            </header>
        <?php endif; ?>

        
        <main class="p-6">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
</div>

</body>
</html><?php /**PATH C:\xampp\htdocs\capstone\resources\views/layouts/app.blade.php ENDPATH**/ ?>