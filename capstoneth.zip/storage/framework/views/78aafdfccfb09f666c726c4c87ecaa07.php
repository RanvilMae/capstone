

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">

    
    <div class="grid grid-cols-1 lg:grid-cols-5 gap-6">
        <div class="lg:col-span-4 p-8 bg-gradient-to-r from-green-100 to-green-200 shadow-xl rounded-2xl">
            <h1 class="text-4xl md:text-5xl font-extrabold text-green-800">
                Welcome, <span class="underline decoration-green-700 underline-offset-4"><?php echo e(auth()->user()->name); ?></span>!
            </h1>
            <p class="mt-4 text-xl md:text-2xl text-gray-600">Here’s all the latest updates for you.</p>
        </div>
        <div class="p-6 bg-white shadow-xl rounded-2xl flex flex-col justify-center items-center text-center">
            <h3 class="text-3xl md:text-4xl font-bold text-green-700"><?php echo e($day); ?></h3>
            <h3 class="text-lg md:text-xl text-green-600"><?php echo e($date); ?></h3>
            <div class="mt-4">
                <span class="text-2xl md:text-3xl font-bold text-green-800"><?php echo e($icon); ?> <?php echo e($temperature); ?>°C</span>
                <p class="text-sm md:text-base text-gray-500 capitalize"><?php echo e($condition); ?></p>
            </div>
        </div>
    </div>

    <hr class="border-gray-300 my-6">

    
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <?php
            $kpis = [
                ['label' => 'Farmers', 'icon' => 'fa-wheat-awn', 'value' => $totalFarmers],
                ['label' => 'Latex (kg)', 'icon' => 'fa-glass-water-droplet', 'value' => number_format($totalWeight, 2)],
                ['label' => 'Rubber Trees', 'icon' => 'fa-tree', 'value' => $totalPlots],
                ['label' => 'Top Contribution', 'icon' => 'fa-arrow-trend-up', 'value' => $topPlot->contribution_percent ?? 0 . '%'],
            ];
        ?>

        <?php $__currentLoopData = $kpis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kpi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="p-6 bg-white shadow-xl rounded-2xl hover:shadow-2xl transition-shadow duration-300">
            <p class="text-sm text-gray-400">Total</p>
            <p class="mt-2 text-xl font-semibold text-gray-800 flex items-center gap-2">
                <i class="fa-solid <?php echo e($kpi['icon']); ?> text-green-600"></i> <?php echo e($kpi['label']); ?>

            </p>
            <p class="mt-4 text-center text-green-700 text-5xl font-bold"><?php echo e($kpi['value']); ?></p>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-6">
        <div class="lg:col-span-3 p-6 bg-white shadow-xl rounded-2xl overflow-x-auto">
            <h3 class="text-xl font-semibold mb-4 text-green-700">Monthly DSS Recommendation</h3>
            <table class="w-full text-sm md:text-base">
                <thead class="bg-green-100 text-green-700 uppercase text-left">
                    <tr>
                        <th class="py-2 px-4">Month</th>
                        <th class="py-2 px-4 text-center">DSS Score</th>
                        <th class="py-2 px-4 text-center">Recommendation</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $monthlyDSS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="border-b hover:bg-green-50 transition-colors">
                        <td class="py-2 px-4"><?php echo e($dss['month']); ?></td>
                        <td class="py-2 px-4 text-center font-bold"><?php echo e($dss['score']); ?></td>
                        <td class="py-2 px-4 text-center"><?php echo e($dss['recommendation']); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-6">
        
        <div class="lg:col-span-2 p-6 bg-white shadow-xl rounded-2xl">
            <h3 class="text-lg font-semibold mb-4 text-green-700">Latex Production Trend</h3>
            <canvas id="productionTrend" class="w-full h-64 md:h-80"></canvas>
        </div>

        
        <div class="p-6 bg-white shadow-xl rounded-2xl flex flex-col justify-center items-center">
            <h3 class="text-lg font-semibold text-green-700 mb-2">Latex Quality Index</h3>
            <canvas id="qualityGauge" class="w-32 h-32 md:w-48 md:h-48"></canvas>
            <p class="mt-4 text-3xl md:text-4xl font-bold text-green-600"><?php echo e($qualityIndex); ?>%</p>
        </div>
    </div>

    
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
        
        <div class="p-6 bg-white shadow-xl rounded-2xl">
            <h3 class="text-lg font-semibold mb-4 text-green-700">Top Contributors</h3>
            <ul class="space-y-2">
                <?php $__currentLoopData = $topContributors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contributor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="flex justify-between bg-green-50 p-3 rounded-lg hover:bg-green-100 transition-colors">
                    <span><?php echo e($contributor->name); ?></span>
                    <span class="font-bold text-green-700"><?php echo e(number_format($contributor->total_latex, 2)); ?> kg</span>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>

        
        <div class="p-6 bg-white shadow-xl rounded-2xl">
            <h3 class="text-lg font-semibold mb-4 text-green-700">Monthly Quality Trend</h3>
            <canvas id="qualityTrend" class="w-full h-64 md:h-80"></canvas>
        </div>
    </div>

</div>


<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    // Production Trend (Multiple Farmers)
    const trendCtx = document.getElementById('productionTrend').getContext('2d');
    new Chart(trendCtx, {
        type: 'line',
        data: {
            labels: <?php echo json_encode($chartLabels, 15, 512) ?>,
            datasets: <?php echo json_encode($chartData, 15, 512) ?>
        },
        options: {
            plugins: {
                legend: { display: true, position: 'bottom' }
            },
            scales: {
                y: { beginAtZero: true },
                x: { grid: { display: false } }
            }
        }
    });

    // Quality Gauge
    new Chart(document.getElementById('qualityGauge'), {
        type: 'doughnut',
        data: {
            datasets: [{
                data: [<?php echo e($qualityIndex); ?>, <?php echo e(100 - $qualityIndex); ?>],
                backgroundColor: ['#22c55e', '#e5e7eb'],
                borderWidth: 0
            }]
        },
        options: {
            rotation: -90,
            circumference: 180,
            cutout: '80%',
            plugins: { legend: { display: false }, tooltip: { enabled: false } }
        }
    });

    // Monthly Quality Trend
    new Chart(document.getElementById('qualityTrend'), {
        type: 'line',
        data: {
            labels: <?php echo json_encode($qualityLabels, 15, 512) ?>,
            datasets: [{
                label: 'Quality Index',
                data: <?php echo json_encode($qualityData, 15, 512) ?>,
                borderColor: '#16a34a',
                backgroundColor: 'rgba(34,197,94,0.2)',
                tension: 0.4,
                fill: true
            }]
        },
        options: {
            plugins: { legend: { display: true } },
            scales: { y: { beginAtZero: true, max: 100 } }
        }
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\capstone\resources\views/dashboard/admin.blade.php ENDPATH**/ ?>