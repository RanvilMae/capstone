

<?php $__env->startSection('title', __('User Management')); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto p-6">
    <div class="bg-white shadow-xl rounded-2xl p-8 space-y-6">
        
        <div class="flex flex-col md:flex-row md:justify-between md:items-center">
            <h1 class="text-3xl font-extrabold text-green-700 mb-4 md:mb-0"><?php echo e(__('User Management')); ?></h1>
            <a href="<?php echo e(route('admin.users.create-user')); ?>"
               class="inline-flex items-center px-5 py-2 text-white bg-green-600 rounded-xl hover:bg-green-700 shadow transition duration-300">
                <i class="fa-solid fa-plus mr-2"></i> <?php echo e(__('Add User')); ?>

            </a>
        </div>

        
        <?php if(session('success')): ?>
        <div 
            x-data="{ show: true }" 
            x-show="show" 
            x-init="setTimeout(() => show = false, 5000)" 
            class="fixed top-6 right-6 z-50 flex items-center bg-green-600 text-white px-4 py-3 rounded-lg shadow-lg transition transform duration-300"
            x-transition:enter="transform ease-out duration-300"
            x-transition:enter-start="opacity-0 translate-y-2"
            x-transition:enter-end="opacity-100 translate-y-0"
            x-transition:leave="transform ease-in duration-300"
            x-transition:leave-start="opacity-100 translate-y-0"
            x-transition:leave-end="opacity-0 translate-y-2"
        >
            <svg class="w-5 h-5 mr-2 fill-current" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                <path fill="currentColor" d="M10 18a8 8 0 100-16 8 8 0 000 16zm-1-7V7h2v4h-2zm0 4h2v2h-2v-2z" />
            </svg>
            <span><?php echo e(__(session('success'))); ?></span>
            <button @click="show = false" class="ml-4 text-white hover:text-gray-200">&times;</button>
        </div>
        <?php endif; ?>

        
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200 rounded-xl">
                <thead class="bg-green-600 text-white uppercase text-sm">
                    <tr>
                        <th class="px-6 py-3 text-left"><?php echo e(__('Name')); ?></th>
                        <th class="px-6 py-3 text-left"><?php echo e(__('Email')); ?></th>
                        <th class="px-6 py-3 text-left"><?php echo e(__('Role')); ?></th>
                        <th class="px-6 py-3 text-left"><?php echo e(__('Status')); ?></th>
                        <th class="px-6 py-3 text-center"><?php echo e(__('Actions')); ?></th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200 text-sm">
                    <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="hover:bg-green-50 transition duration-200 <?php if($user->trashed()): ?> bg-gray-100 <?php endif; ?>">
                            <td class="px-6 py-3 font-medium text-gray-800"><?php echo e($user->name); ?></td>
                            <td class="px-6 py-3 text-gray-600"><?php echo e($user->email); ?></td>
                            <td class="px-6 py-3 text-gray-600"><?php echo e(__(ucfirst($user->role))); ?></td>
                            <td class="px-6 py-3">
                                <?php if($user->trashed()): ?>
                                    <span class="inline-flex items-center gap-1 px-2 py-1 text-white bg-red-600 rounded">
                                        <i class="fa-solid fa-xmark"></i> <?php echo e(__('Rejected')); ?>

                                    </span>
                                <?php elseif($user->is_approved): ?>
                                    <span class="inline-flex items-center gap-1 px-2 py-1 text-white bg-green-700 rounded">
                                        <i class="fa-solid fa-check"></i> <?php echo e(__('Approved')); ?>

                                    </span>
                                <?php else: ?>
                                    <span class="inline-flex items-center gap-1 px-2 py-1 text-white bg-yellow-600 rounded">
                                        <i class="fa-solid fa-hourglass-half"></i> <?php echo e(__('Pending')); ?>

                                    </span>
                                <?php endif; ?>
                            </td>
                            <td class="px-6 py-3 flex justify-center gap-2 flex-wrap">
                                <?php if(!$user->trashed()): ?>
                                    
                                    <a href="<?php echo e(route('admin.users.edit', $user)); ?>"
                                       class="inline-flex items-center gap-1 px-3 py-1 text-white bg-blue-600 rounded-lg hover:bg-blue-700 transition duration-200">
                                        <i class="fa-solid fa-pen-to-square"></i> <?php echo e(__('Edit')); ?>

                                    </a>
                                    
                                    <form action="<?php echo e(route('admin.users.destroy', $user)); ?>" method="POST" class="inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit"
                                            class="inline-flex items-center gap-1 px-3 py-1 text-white bg-red-600 rounded-lg hover:bg-red-700 transition duration-200"
                                            onclick="return confirm('<?php echo e(__('Are you sure you want to reject this user?')); ?>')">
                                            <i class="fa-solid fa-xmark"></i> <?php echo e(__('Reject')); ?>

                                        </button>
                                    </form>
                                    
                                    <?php if(!$user->is_approved): ?>
                                        <form action="<?php echo e(route('admin.users.approve', $user)); ?>" method="POST" class="inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PATCH'); ?>
                                            <button type="submit"
                                                class="inline-flex items-center gap-1 px-3 py-1 text-white bg-green-500 rounded-lg hover:bg-green-600 transition duration-200">
                                                <i class="fa-solid fa-check"></i> <?php echo e(__('Approve')); ?>

                                            </button>
                                        </form>
                                    <?php endif; ?>
                                <?php else: ?>
                                    
                                    <form action="<?php echo e(route('admin.users.restore', $user->id)); ?>" method="POST" class="inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PATCH'); ?>
                                        <button type="submit"
                                            class="inline-flex items-center gap-1 px-3 py-1 text-white bg-blue-600 rounded-lg hover:bg-blue-700 transition duration-200">
                                            <i class="fa-solid fa-rotate-left"></i> <?php echo e(__('Restore')); ?>

                                        </button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="px-6 py-4 text-center text-gray-500">
                                <?php echo e(__('No users found.')); ?>

                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\capstone\resources\views/admin/users/users.blade.php ENDPATH**/ ?>