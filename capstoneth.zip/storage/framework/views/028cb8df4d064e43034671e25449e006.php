

<?php $__env->startSection('title', __('Edit Farmer')); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto p-6">
    <div class="bg-white shadow-xl rounded-2xl p-8 space-y-6 max-w-2xl mx-auto">
        
        <h1 class="text-3xl font-extrabold text-green-700"><?php echo e(__('Edit Farmer')); ?></h1>

        
        <?php if($errors->any()): ?>
            <div 
                x-data="{ show: true }" 
                x-show="show" 
                x-init="setTimeout(() => show = false, 7000)" 
                class="fixed top-6 right-6 z-50 flex flex-col bg-red-600 text-white px-4 py-3 rounded-lg shadow-lg space-y-2 transition transform duration-300"
                x-transition:enter="transform ease-out duration-300"
                x-transition:enter-start="opacity-0 translate-y-2"
                x-transition:enter-end="opacity-100 translate-y-0"
                x-transition:leave="transform ease-in duration-300"
                x-transition:leave-start="opacity-100 translate-y-0"
                x-transition:leave-end="opacity-0 translate-y-2"
            >
                <div class="flex justify-between items-center">
                    <strong class="font-semibold"><?php echo e(__('Please fix the following errors')); ?>:</strong>
                    <button @click="show = false" class="ml-4 text-white hover:text-gray-200">&times;</button>
                </div>
                <ul class="list-disc list-inside text-sm">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e(__($error)); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        
        <form action="<?php echo e(auth()->user()->hasRole('admin') ? route('admin.farmer.update', $farmer) : route('farmer.update', $farmer)); ?>" method="POST" class="space-y-6">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>

            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label class="block mb-2 font-semibold text-gray-700"><?php echo e(__('Name')); ?></label>
                    <input type="text" name="name" value="<?php echo e(old('name') ?? $farmer->name); ?>"
                        class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-400 focus:outline-none"
                        required>
                </div>

                <div>
                    <label class="block mb-2 font-semibold text-gray-700"><?php echo e(__('Email')); ?></label>
                    <input type="email" name="email" value="<?php echo e(old('email') ?? $farmer->email); ?>"
                        class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-400 focus:outline-none"
                        required>
                </div>
            </div>

            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label class="block mb-2 font-semibold text-gray-700"><?php echo e(__('Phone')); ?></label>
                    <input type="text" name="phone" value="<?php echo e(old('phone') ?? $farmer->phone); ?>"
                        class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-400 focus:outline-none">
                </div>

                <div>
                    <label class="block mb-2 font-semibold text-gray-700"><?php echo e(__('Address')); ?></label>
                    <input type="text" name="address" value="<?php echo e(old('address') ?? $farmer->address); ?>"
                        class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-400 focus:outline-none">
                </div>
            </div>

            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label class="block mb-2 font-semibold text-gray-700"><?php echo e(__('Farm Location')); ?></label>
                    <input type="text" name="farm_location" value="<?php echo e(old('farm_location') ?? $farmer->farm_location); ?>"
                        class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-400 focus:outline-none">
                </div>

                <div>
                    <label class="block mb-2 font-semibold text-gray-700"><?php echo e(__('Farm Size (ha)')); ?></label>
                    <input type="number" step="0.01" name="farm_size" value="<?php echo e(old('farm_size') ?? $farmer->farm_size); ?>"
                        class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-400 focus:outline-none">
                </div>
            </div>

            
            <div>
                <label class="block mb-2 font-semibold text-gray-700"><?php echo e(__('Notes')); ?></label>
                <textarea name="notes"
                    class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-400 focus:outline-none"
                    rows="4"><?php echo e(old('notes') ?? $farmer->notes); ?></textarea>
            </div>

            
            <button type="submit"
                class="w-full py-3 bg-green-600 text-white font-semibold rounded-xl hover:bg-green-700 transition duration-300 shadow-md">
                <?php echo e(__('Update Farmer')); ?>

            </button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\capstone\resources\views/farmer/edit.blade.php ENDPATH**/ ?>