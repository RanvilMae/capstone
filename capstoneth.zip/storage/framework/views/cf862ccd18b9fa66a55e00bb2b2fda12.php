

<?php $__env->startSection('content'); ?>
<div class="container mx-auto p-6">
    <div class="bg-white shadow-xl rounded-2xl p-8">
        <h2 class="mb-6 text-3xl font-extrabold text-green-700"><?php echo e(__('Latex Transactions')); ?></h2>

        <form method="GET" class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <select name="plot_id" class="p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-400 focus:outline-none">
                <option value=""><?php echo e(__('All Plots')); ?></option>
                <?php $__currentLoopData = $plots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($plot->id); ?>" <?php echo e(request('plot_id') == $plot->id ? 'selected' : ''); ?>>
                        <?php echo e($plot->plot_location); ?> (<?php echo e($plot->plot_size_rai); ?> <?php echo e(__('Rai')); ?>) - <?php echo e($plot->farmer->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <select name="farmer_id" class="p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-400 focus:outline-none">
                <option value=""><?php echo e(__('All Farmers')); ?></option>
                <?php $__currentLoopData = $plots->pluck('farmer')->unique('id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $farmer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($farmer->id); ?>" <?php echo e(request('farmer_id') == $farmer->id ? 'selected' : ''); ?>>
                        <?php echo e($farmer->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <select name="production_year_id" class="p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-400 focus:outline-none">
                <option value=""><?php echo e(__('All Years')); ?></option>
                <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($year->id); ?>" <?php echo e(request('production_year_id') == $year->id ? 'selected' : ''); ?>>
                        <?php echo e(__('FY')); ?> <?php echo e($year->year_label); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <button type="submit" class="px-4 py-3 bg-green-500 text-white font-semibold rounded-xl hover:bg-green-600 transition-colors duration-300">
                <?php echo e(__('Filter')); ?>

            </button>
        </form>

        <div class="overflow-x-auto rounded-xl shadow-inner border border-gray-200">
            <table class="min-w-full bg-white divide-y divide-gray-200">
                <thead class="bg-green-100 text-green-700">
                    <tr>
                        <th class="px-4 py-2 text-left"><?php echo e(__('Date')); ?></th>
                        <th class="px-4 py-2 text-left"><?php echo e(__('Plot')); ?></th>
                        <th class="px-4 py-2 text-left"><?php echo e(__('Farmer')); ?></th>
                        <th class="px-4 py-2 text-right"><?php echo e(__('Volume (kg)')); ?></th>
                        <th class="px-4 py-2 text-right"><?php echo e(__('DRC (%)')); ?></th>
                        <th class="px-4 py-2 text-right"><?php echo e(__('Dry Rubber (kg)')); ?></th>
                        <th class="px-4 py-2 text-right"><?php echo e(__('Price/kg')); ?></th>
                        <th class="px-4 py-2 text-right"><?php echo e(__('Total Amount')); ?></th>
                        <th class="px-4 py-2 text-left"><?php echo e(__('Entered By')); ?></th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="hover:bg-green-50 transition-colors">
                            <td class="px-4 py-2"><?php echo e($t->transaction_date); ?></td>
                            <td class="px-4 py-2"><?php echo e($t->plot->plot_location); ?></td>
                            <td class="px-4 py-2"><?php echo e($t->plot->farmer->name); ?></td>
                            <td class="px-4 py-2 text-right"><?php echo e(number_format($t->volume_kg, 2)); ?></td>
                            <td class="px-4 py-2 text-right"><?php echo e(number_format($t->dry_rubber_content, 2)); ?></td>
                            <td class="px-4 py-2 text-right"><?php echo e(number_format($t->volume_kg * ($t->dry_rubber_content / 100), 2)); ?></td>
                            <td class="px-4 py-2 text-right"><?php echo e(number_format($t->price_per_kg, 2)); ?></td>
                            <td class="px-4 py-2 text-right"><?php echo e(number_format($t->total_amount, 2)); ?></td>
                            <td class="px-4 py-2"><?php echo e($t->user->name); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <div class="mt-4">
            <?php echo e($transactions->withQueryString()->links()); ?>

        </div>

        <h3 class="mt-8 mb-4 text-xl font-bold text-green-700"><?php echo e(__('Totals per Plot')); ?></h3>
        <div class="overflow-x-auto rounded-xl shadow-inner border border-gray-200">
            <table class="min-w-full bg-white divide-y divide-gray-200">
                <thead class="bg-green-100 text-green-700">
                    <tr>
                        <th class="px-4 py-2 text-left"><?php echo e(__('Date')); ?></th>
                        <th class="px-4 py-2 text-left"><?php echo e(__('Plot')); ?></th>
                        <th class="px-4 py-2 text-left"><?php echo e(__('Farmer')); ?></th>
                        <th class="px-4 py-2 text-right"><?php echo e(__('Volume (kg)')); ?></th>
                        <th class="px-4 py-2 text-right"><?php echo e(__('DRC (%)')); ?></th>
                        <th class="px-4 py-2 text-right"><?php echo e(__('Dry Rubber (kg)')); ?></th>
                        <th class="px-4 py-2 text-right"><?php echo e(__('Price/kg')); ?></th>
                        <th class="px-4 py-2 text-right"><?php echo e(__('Total Amount')); ?></th>
                        <th class="px-4 py-2 text-left"><?php echo e(__('Entered By')); ?></th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    <?php $__currentLoopData = $totals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plotId => $total): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $plot = $plots->find($plotId); ?>
                        <?php if($plot): ?>
                        <tr class="hover:bg-green-50 transition-colors">
                            <td class="px-4 py-2"><?php echo e($plot->plot_location); ?></td>
                            <td class="px-4 py-2"><?php echo e($plot->farmer->name); ?></td>
                            <td class="px-4 py-2 text-right"><?php echo e(number_format($total['dry_rubber_weight'], 2)); ?></td>
                            <td class="px-4 py-2 text-right"><?php echo e(number_format($total['total_income'], 2)); ?></td>
                        </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\capstone\resources\views/transactions/index.blade.php ENDPATH**/ ?>